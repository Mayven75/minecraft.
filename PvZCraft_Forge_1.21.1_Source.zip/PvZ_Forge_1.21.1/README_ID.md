# PvZCraft — Minecraft Java Forge 1.21.1 (prototipe awal)

Paket ini adalah **proyek sumber mod**, belum berupa `.jar` siap pasang dan belum merupakan map `.zip`/`.mcworld` siap main. Mod awal menyediakan:
- `/pvz arena` — membangun arena rumput 5 jalur di depan pemain.
- `/pvz wave` — memunculkan satu gelombang dasar berisi 5 zombie.

Ini adalah prototipe fondasi. Tanaman PvZ dengan model, item khusus, sistem matahari, proyektil kacang, dan gelombang otomatis **belum dibuat**. Perintah arena juga mengubah blok di sekitar pemain; uji di dunia baru.

## Target
- Minecraft Java Edition 1.21.1
- Java 21
- Minecraft Forge 52.0.28
- Gradle + koneksi internet saat pertama kali build

## Cara build menjadi mod `.jar`
1. Instal Java Development Kit (JDK) 21.
2. Instal Minecraft Forge 1.21.1 (Forge 52.0.28) di launcher.
3. Instal Gradle 8.8 atau versi yang kompatibel dengan ForgeGradle 6.
4. Ekstrak paket ini ke folder biasa.
5. Buka terminal di folder proyek, lalu jalankan:
   - Windows: `gradle build`
   - macOS/Linux: `gradle build`
6. File hasil build ada di `build/libs/pvzcraft-0.1.0.jar`.
7. Salin file `.jar` ke folder `.minecraft/mods`.
8. Jalankan profil Forge 1.21.1.

## Cara membuat map PvZ
1. Buat dunia Creative baru dengan Forge 1.21.1.
2. Masuk ke dunia, berdiri di tempat yang lapang, dan arahkan pandangan ke arah yang diinginkan.
3. Jalankan `/pvz arena`.
4. Jalankan `/pvz wave` untuk memunculkan zombie.
5. Simpan dan keluar. Dunia tersimpan di `.minecraft/saves/NamaDunia`.

## Batasan dan catatan
- Paket ini berisi kode sumber, bukan binary `.jar` yang sudah dikompilasi.
- Belum ada world save siap pakai; arena dibangun lewat command dalam dunia baru.
- Backup dunia sebelum mencoba di dunia yang sudah ada.
- Jika build gagal karena perubahan API Forge, kirimkan log error agar kode dapat disesuaikan.
