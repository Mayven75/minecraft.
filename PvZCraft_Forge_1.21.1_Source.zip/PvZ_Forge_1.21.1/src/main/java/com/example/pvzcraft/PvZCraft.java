package com.example.pvzcraft;

import com.mojang.brigadier.Command;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.server.ServerStartingEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod(PvZCraft.MOD_ID)
public class PvZCraft {
    public static final String MOD_ID = "pvzcraft";

    public PvZCraft() {
        MinecraftForge.EVENT_BUS.register(this);
    }

    @SubscribeEvent
    public void onRegisterCommands(RegisterCommandsEvent event) {
        event.getDispatcher().register(
            net.minecraft.commands.Commands.literal("pvz")
                .then(net.minecraft.commands.Commands.literal("arena")
                    .executes(ctx -> {
                        if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) {
                            ctx.getSource().sendFailure(Component.literal("Run this command in-game as a player."));
                            return 0;
                        }
                        ServerLevel level = ctx.getSource().getLevel();
                        BlockPos origin = player.blockPosition().relative(player.getDirection(), 5);
                        buildArena(level, origin);
                        ctx.getSource().sendSuccess(() -> Component.literal(
                            "PvZ arena created! Lanes run away from the house. Use /pvz wave to spawn zombies."
                        ), false);
                        return Command.SINGLE_SUCCESS;
                    })
                )
                .then(net.minecraft.commands.Commands.literal("wave")
                    .executes(ctx -> {
                        if (!(ctx.getSource().getEntity() instanceof ServerPlayer player)) {
                            ctx.getSource().sendFailure(Component.literal("Run this command in-game as a player."));
                            return 0;
                        }
                        ServerLevel level = ctx.getSource().getLevel();
                        BlockPos origin = player.blockPosition().relative(player.getDirection(), 20);
                        for (int lane = 0; lane < 5; lane++) {
                            Zombie zombie = EntityType.ZOMBIE.create(level);
                            if (zombie != null) {
                                BlockPos spawn = origin.relative(player.getDirection(), 10)
                                    .relative(player.getDirection().getClockWise(), lane * 2 - 4);
                                zombie.moveTo(spawn.getX() + 0.5, spawn.getY() + 1, spawn.getZ() + 0.5,
                                    player.getYRot(), 0);
                                level.addFreshEntity(zombie);
                            }
                        }
                        ctx.getSource().sendSuccess(() -> Component.literal("A basic zombie wave has spawned!"), false);
                        return Command.SINGLE_SUCCESS;
                    })
                )
        );
    }

    private static void buildArena(ServerLevel level, BlockPos origin) {
        Direction forward = level.getNearestPlayer(origin.getX(), origin.getY(), origin.getZ(), 100, false) != null
            ? level.getNearestPlayer(origin.getX(), origin.getY(), origin.getZ(), 100, false).getDirection()
            : Direction.SOUTH;
        // Build a 15-column x 5-lane lawn. The player faces down the lanes.
        Direction right = forward.getClockWise();
        BlockPos start = origin;
        for (int x = 0; x < 17; x++) {
            for (int lane = -5; lane <= 5; lane++) {
                BlockPos top = start.relative(forward, x).relative(right, lane);
                level.setBlock(top.below(), Blocks.DIRT.defaultBlockState(), 3);
                BlockState surface = (lane == -5 || lane == 5 || x == 0 || x == 16)
                    ? Blocks.OAK_PLANKS.defaultBlockState()
                    : Blocks.GRASS_BLOCK.defaultBlockState();
                level.setBlock(top, surface, 3);
                // Light the play area without placing torches on the lawn.
                if (x == 0 && (lane == -3 || lane == 0 || lane == 3)) {
                    level.setBlock(top.above(), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }
        // House and entry marker behind the player-facing side.
        for (int dx = -3; dx <= 3; dx++) {
            for (int dy = 0; dy <= 3; dy++) {
                BlockPos wall = start.relative(right, dx).relative(forward.getOpposite(), 2).above(dy);
                level.setBlock(wall, (dx == -3 || dx == 3 || dy == 3)
                    ? Blocks.OAK_PLANKS.defaultBlockState()
                    : Blocks.AIR.defaultBlockState(), 3);
            }
        }
        level.setBlock(start.relative(forward.getOpposite(), 2).above(), Blocks.OAK_DOOR.defaultBlockState(), 3);
    }
}
